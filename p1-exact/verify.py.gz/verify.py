#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, pathlib, random, time, urllib.error, urllib.parse, urllib.request
from collections import defaultdict

RPC = "https://rpc.mainnet.chain.robinhood.com"
BS = "https://robinhoodchain.blockscout.com/api/v2"
ZERO = "0x" + "0"*40
TRANSFER = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
SEADROP_MINT = "0xe90cf9cc0a552cf52ea6ff74ece0f1c8ae8cc9ad630d3181f55ac43ca076b7d6"
ORDER_FULFILLED = "0x9d9af8e38d66c62e2c12f0225249fd9d721c54b83f48d9352c97c6cacdcb6f31"
UA = "RHC-P1-Exact-Verification/1.0"

def norm(v):
    if isinstance(v, dict):
        for k in ("hash","address","address_hash"):
            if v.get(k): return norm(v[k])
    return str(v).lower() if v is not None else None

def intval(v, default=None):
    if v is None: return default
    if isinstance(v, int): return v
    if isinstance(v, str):
        try: return int(v,16) if v.startswith("0x") else int(v)
        except Exception: return default
    if isinstance(v, dict):
        for k in ("value","amount"):
            if k in v: return intval(v[k],default)
    return default

def words(data):
    h=str(data or "0x")[2:]
    if len(h)%64: raise ValueError("unaligned ABI data")
    return [int(h[i:i+64],16) for i in range(0,len(h),64)]

def topic_addr(topic):
    return "0x"+str(topic)[-40:].lower()

class Client:
    def __init__(self):
        self.rpc_id=0
        self.stats=defaultdict(int)
        self.last=0.0
    def req(self,url,data=None,attempts=8):
        headers={"User-Agent":UA,"Accept":"application/json"}
        body=None
        if data is not None:
            body=json.dumps(data).encode()
            headers["Content-Type"]="application/json"
        last=None
        for attempt in range(attempts):
            wait=.15-(time.monotonic()-self.last)
            if wait>0: time.sleep(wait)
            try:
                r=urllib.request.Request(url,data=body,headers=headers)
                with urllib.request.urlopen(r,timeout=60) as resp:
                    raw=resp.read(); self.last=time.monotonic()
                    self.stats[f"http_{resp.status}"]+=1
                    return resp.status, json.loads(raw.decode()) if raw else None
            except urllib.error.HTTPError as exc:
                self.last=time.monotonic(); self.stats[f"http_{exc.code}"]+=1
                raw=exc.read(); last=exc
                if exc.code in (400,404):
                    try: payload=json.loads(raw.decode())
                    except Exception: payload={"error":raw.decode("utf-8","replace")}
                    return exc.code,payload
                if exc.code==429 or exc.code>=500:
                    time.sleep(min(30,2**attempt+random.random()))
                    continue
                raise
            except Exception as exc:
                last=exc; self.stats["network_error"]+=1
                if attempt+1<attempts:
                    time.sleep(min(20,2**attempt+random.random()))
                    continue
        raise RuntimeError(f"request failed {url}: {last!r}")
    def rpc(self,method,params):
        self.rpc_id+=1
        status,payload=self.req(RPC,{"jsonrpc":"2.0","id":self.rpc_id,"method":method,"params":params})
        if status!=200 or not isinstance(payload,dict) or payload.get("error"):
            raise RuntimeError({"method":method,"status":status,"payload":payload})
        return payload.get("result")
    def bs(self,path):
        return self.req(BS+path)

def write_csv(path,rows):
    fields=sorted({k for r in rows for k in r}) if rows else ["empty"]
    with path.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction="ignore"); w.writeheader()
        for r in rows:
            w.writerow({k:json.dumps(v,ensure_ascii=False,sort_keys=True) if isinstance(v,(dict,list,tuple)) else v for k,v in r.items()})

def flatten_calls(node,out):
    if isinstance(node,dict):
        frm=norm(node.get("from")); to=norm(node.get("to")); value=intval(node.get("value"),0) or 0
        if to and value>0:
            out.append({"from":frm,"to":to,"value_wei":value,"type":node.get("type") or node.get("callType")})
        for key in ("calls","children"):
            for child in node.get(key) or []: flatten_calls(child,out)
    elif isinstance(node,list):
        for x in node: flatten_calls(x,out)

def receipt_transfer_rows(receipt):
    nft=[]; fungible=[]
    for log in receipt.get("logs") or []:
        topics=[norm(x) for x in log.get("topics") or []]
        if not topics or topics[0]!=TRANSFER or len(topics)<3: continue
        emitter=norm(log.get("address")); frm=topic_addr(topics[1]); to=topic_addr(topics[2])
        li=intval(log.get("logIndex"))
        if len(topics)==4:
            nft.append({"contract":emitter,"from":frm,"to":to,"token_id":int(topics[3],16),"log_index":li})
        else:
            fungible.append({"token":emitter,"from":frm,"to":to,"amount_raw":intval(log.get("data"),0) or 0,"log_index":li})
    return nft,fungible

def verify_mint(client,event,raw_dir):
    txh=norm(event["transaction_hash"])
    tx=client.rpc("eth_getTransactionByHash",[txh])
    receipt=client.rpc("eth_getTransactionReceipt",[txh])
    if not tx or not receipt: raise RuntimeError(f"missing mint tx {txh}")
    block_no=intval(receipt.get("blockNumber")); block=client.rpc("eth_getBlockByNumber",[hex(block_no),False])
    (raw_dir/f"mint_{txh}.json").write_text(json.dumps({"tx":tx,"receipt":receipt,"block":block},indent=2,sort_keys=True),encoding="utf-8")
    sea=[]
    for log in receipt.get("logs") or []:
        topics=[norm(x) for x in log.get("topics") or []]
        if topics and topics[0]==SEADROP_MINT:
            vals=words(log.get("data"))
            if len(topics)>=4 and len(vals)>=5:
                sea.append({
                    "log_index":intval(log.get("logIndex")),
                    "nft_contract":topic_addr(topics[1]),
                    "minter":topic_addr(topics[2]),
                    "fee_recipient":topic_addr(topics[3]),
                    "payer":"0x"+f"{vals[0]:064x}"[-40:],
                    "quantity":vals[1],"unit_mint_price_wei":vals[2],"fee_bps":vals[3],"drop_stage_index":vals[4],
                })
    nft,_=receipt_transfer_rows(receipt)
    zero=[r for r in nft if r["contract"]==norm(event["nft_contract"]) and r["from"]==ZERO and r["to"]==norm(event["minter"])]
    match=[r for r in sea if r["log_index"]==int(event["log_index"])]
    match=match[0] if len(match)==1 else None
    fields_ok=bool(match and
        match["nft_contract"]==norm(event["nft_contract"]) and match["minter"]==norm(event["minter"]) and
        match["payer"]==norm(event["payer"]) and match["quantity"]==int(event["quantity"]) and
        match["unit_mint_price_wei"]==int(event["unit_mint_price_wei"]) and
        match["drop_stage_index"]==int(event["drop_stage_index"]))
    zero_ok=len(zero)==int(event["quantity"])
    receipt_ok=intval(receipt.get("status"))==1 and block_no==int(event["block_number"])
    gas_used=intval(receipt.get("gasUsed"),0) or 0
    gas_price=intval(receipt.get("effectiveGasPrice"),intval(tx.get("gasPrice"),0)) or 0
    return {
        **event,
        "tx_from":norm(tx.get("from")),
        "receipt_status":intval(receipt.get("status")),
        "block_hash":norm(receipt.get("blockHash")),
        "gas_used":gas_used,"effective_gas_price_wei":gas_price,"gas_cost_wei":gas_used*gas_price,
        "all_in_primary_cost_wei":int(event["gross_mint_value_wei"])+gas_used*gas_price,
        "zero_transfer_count":len(zero),"zero_transfer_token_ids":[r["token_id"] for r in zero],
        "seadrop_fields_verified":fields_ok,"zero_transfer_quantity_verified":zero_ok,
        "canonical_receipt_verified":receipt_ok and fields_ok and zero_ok,
        "economic_route":"SELF_FUNDED" if norm(event["minter"])==norm(event["payer"]) else "ROUTED_PAYER_UNPROVEN",
    }

def token_provenance(client,contract,token_id,seller,sale_tx):
    status,payload=client.bs(f"/tokens/{contract}/instances/{token_id}/transfers")
    items=payload.get("items",[]) if status==200 and isinstance(payload,dict) else []
    prior=[]
    for r in items:
        to=norm(r.get("to"))
        txh=norm(r.get("transaction_hash") or (r.get("transaction") or {}).get("hash") if isinstance(r.get("transaction"),dict) else r.get("transaction_hash"))
        if to==seller and txh!=sale_tx: prior.append(r)
    return {"http_status":status,"prior_to_seller":prior,"all_rows":items}

def verify_sale(client,group,raw_dir):
    txh=norm(group["tx_hash"]); seller=norm(group["seller"]); contract=norm(group["collection_contract"])
    tx=client.rpc("eth_getTransactionByHash",[txh]); receipt=client.rpc("eth_getTransactionReceipt",[txh])
    if not tx or not receipt: raise RuntimeError(f"missing sale tx {txh}")
    block_no=intval(receipt.get("blockNumber")); block=client.rpc("eth_getBlockByNumber",[hex(block_no),False])
    bs_status,bs_tx=client.bs(f"/transactions/{txh}")
    tr_status,trace=client.bs(f"/transactions/{txh}/raw-trace")
    (raw_dir/f"sale_{txh}.json").write_text(json.dumps({"tx":tx,"receipt":receipt,"block":block,"blockscout_status":bs_status,"blockscout_tx":bs_tx,"trace_status":tr_status,"trace":trace},indent=2,sort_keys=True),encoding="utf-8")
    nft,fungible=receipt_transfer_rows(receipt)
    expected={(int(t["token_id"]),norm(t["buyer"])) for t in group["tokens"]}
    observed={(r["token_id"],r["to"]) for r in nft if r["contract"]==contract and r["from"]==seller}
    expected_transfers_ok=expected.issubset(observed)
    order_count=sum(1 for log in receipt.get("logs") or [] if (log.get("topics") or []) and norm(log["topics"][0])==ORDER_FULFILLED)
    calls=[]; flatten_calls(trace,calls)
    native_to_seller=sum(r["value_wei"] for r in calls if r["to"]==seller)
    erc20_to_seller=[r for r in fungible if r["to"]==seller and r["amount_raw"]>0]
    payment_proven=bool(native_to_seller or erc20_to_seller)
    prov=[]
    for t in group["tokens"]:
        prov.append({"token_id":int(t["token_id"]),"buyer":norm(t["buyer"]),"provenance":token_provenance(client,contract,int(t["token_id"]),seller,txh)})
    acquisition_found=all(bool(x["provenance"]["prior_to_seller"]) for x in prov)
    return {
        "tx_hash":txh,"seller":seller,"collection_contract":contract,"collection_name":group["collection_name"],
        "expected_token_count":len(expected),"observed_seller_transfer_count":sum(1 for r in nft if r["contract"]==contract and r["from"]==seller),
        "expected_transfers_verified":expected_transfers_ok,"order_fulfilled_count":order_count,
        "tx_value_wei":intval(tx.get("value"),0) or 0,"native_to_seller_wei":native_to_seller,
        "erc20_to_seller":erc20_to_seller,"payment_proven":payment_proven,
        "receipt_status":intval(receipt.get("status")),"block_number":block_no,"block_hash":norm(receipt.get("blockHash")),
        "token_provenance":prov,"all_tokens_have_prior_transfer_to_seller":acquisition_found,
        "exact_acquisition_cost_proven":False,"realized_pnl_calculable":False,
        "source_rows":group["source_rows"],"source_tokens":group["tokens"],
        "canonical_sale_verified":intval(receipt.get("status"))==1 and expected_transfers_ok and order_count>=1 and payment_proven,
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--input",required=True); ap.add_argument("--out",required=True)
    args=ap.parse_args()
    out=pathlib.Path(args.out); raw=out/"raw"; raw.mkdir(parents=True,exist_ok=True)
    data=json.loads(pathlib.Path(args.input).read_text())
    c=Client()
    mint_rows=[]; sale_rows=[]; errors=[]
    for e in data["events"]:
        try: mint_rows.append(verify_mint(c,e,raw))
        except Exception as exc: errors.append({"stage":"mint","tx_hash":e["transaction_hash"],"wallet":e["minter"],"error":repr(exc)})
    for g in data["sale_groups"]:
        try: sale_rows.append(verify_sale(c,g,raw))
        except Exception as exc: errors.append({"stage":"sale","tx_hash":g["tx_hash"],"wallet":g["seller"],"error":repr(exc)})
    write_csv(out/"mint_event_verification.csv",mint_rows)
    write_csv(out/"sale_order_verification.csv",sale_rows)
    write_csv(out/"errors.csv",errors)
    wallets=sorted(set(data["source_only_wallets"]) | {norm(r["minter"]) for r in mint_rows} | {norm(r["seller"]) for r in sale_rows})
    classifications=[]
    for w in wallets:
        wm=[r for r in mint_rows if norm(r["minter"])==w]
        ws=[r for r in sale_rows if norm(r["seller"])==w]
        strict=[r for r in wm if r["canonical_receipt_verified"] and r["drop_stage_index"]==0 and r["unit_mint_price_wei"]>0 and r["economic_route"]=="SELF_FUNDED"]
        routed=[r for r in wm if r["economic_route"]!="SELF_FUNDED"]
        mixed=[r for r in wm if r["is_free"] or r["collection_name"] in ("PUNKBLOCK","Robinhood Spookers","Rabbit Hood Society","StonkFrankiez")]
        classifications.append({
            "wallet":w,"verified_mint_events":len(wm),"verified_strict_self_funded_projects":len(set(r["nft_contract"] for r in strict)),
            "routed_payer_events":len(routed),"mixed_or_free_events":len(mixed),
            "verified_sale_orders":sum(bool(r["canonical_sale_verified"]) for r in ws),
            "sales_with_acquisition_provenance":sum(bool(r["all_tokens_have_prior_transfer_to_seller"]) for r in ws),
            "selection_alpha_status":"LOW_SAMPLE_NOT_EVALUATABLE" if strict else ("PRIVILEGED_OR_ROUTED_SIGNAL_ONLY" if routed else "NOT_EVALUATED"),
            "execution_alpha_status":"NOT_EVALUATABLE_EXACT_ACQUISITION_COST_MISSING" if ws else "NOT_EVALUATED",
            "copy_alpha_status":"NOT_EVALUATED","production_approved":False,
        })
    write_csv(out/"wallet_classification.csv",classifications)
    validation={
        "status":"PASS" if not errors and len(mint_rows)==len(data["events"]) and all(r["canonical_receipt_verified"] for r in mint_rows) and len(sale_rows)==len(data["sale_groups"]) else "FAIL",
        "expected_mint_events":len(data["events"]),"verified_mint_rows":len(mint_rows),
        "all_mints_canonical":all(r["canonical_receipt_verified"] for r in mint_rows) if mint_rows else False,
        "expected_sale_groups":len(data["sale_groups"]),"verified_sale_rows":len(sale_rows),
        "canonical_sale_orders":sum(bool(r["canonical_sale_verified"]) for r in sale_rows),
        "error_count":len(errors),"source_only_wallets":data["source_only_wallets"],"production_approved_wallets":0,
        "request_stats":dict(c.stats),
    }
    (out/"VALIDATION.json").write_text(json.dumps(validation,indent=2,sort_keys=True),encoding="utf-8")
    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file(): manifest.append({"path":str(p.relative_to(out)),"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()})
    (out/"MANIFEST.json").write_text(json.dumps(manifest,indent=2,sort_keys=True),encoding="utf-8")
    print(json.dumps(validation,sort_keys=True))
    if validation["status"]!="PASS": raise SystemExit(1)
if __name__=="__main__": main()
