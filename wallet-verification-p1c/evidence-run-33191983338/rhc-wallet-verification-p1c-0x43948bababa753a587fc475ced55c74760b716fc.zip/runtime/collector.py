#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

CHAIN_ID = 4663
ZERO = "0x0000000000000000000000000000000000000000"
RPC_URL = "https://rpc.mainnet.chain.robinhood.com"
EXPLORERS = [
    "https://robinhoodchain.blockscout.com",
    "https://explorer.hoodmarketcap.com",
]
ROBINSCAN = "https://robinscan.io"
UA = "RHC-Wallet-Evidence-Verification/1.0"
TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
SEADROP_TOPIC = "0xe90cf9cc0a552cf52ea6ff74ece0f1c8ae8cc9ad630d3181f55ac43ca076b7d6"
ORDER_FULFILLED_TOPIC = "0x9d9af8e38d66c62e2c12f0225249fd9d721c54b83f48d9352c97c6cacdcb6f31"
ADDR_RE = re.compile(r"^0x[a-f0-9]{40}$")
HASH_RE = re.compile(r"^0x[a-f0-9]{64}$")


def jdump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def intish(value: Any, default: int | None = None) -> int | None:
    if value is None:
        return default
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        value = value.strip()
        try:
            return int(value, 16) if value.startswith("0x") else int(value)
        except ValueError:
            return default
    return default


def address(value: Any) -> str | None:
    if isinstance(value, dict):
        value = value.get("hash") or value.get("address") or value.get("address_hash")
    if isinstance(value, str) and re.fullmatch(r"0x[a-fA-F0-9]{40}", value):
        return value.lower()
    return None


def topic_address(value: str) -> str:
    return "0x" + value.lower().removeprefix("0x").rjust(64, "0")


def topic_uint(value: int | str) -> str:
    return "0x" + hex(int(value))[2:].rjust(64, "0")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class Client:
    def __init__(self, delay: float = 0.28, attempts: int = 8, timeout: int = 60):
        self.delay = delay
        self.attempts = attempts
        self.timeout = timeout
        self.last = 0.0
        self.stats: dict[str, int] = defaultdict(int)

    def pace(self) -> None:
        wait = self.delay - (time.monotonic() - self.last)
        if wait > 0:
            time.sleep(wait)

    def request(self, url: str, *, data: bytes | None = None, headers: dict[str, str] | None = None) -> tuple[int, dict[str, str], bytes]:
        hdr = {"Accept": "application/json", "User-Agent": UA}
        if headers:
            hdr.update(headers)
        last_error: Exception | None = None
        for attempt in range(self.attempts):
            self.pace()
            req = urllib.request.Request(url, data=data, headers=hdr, method="POST" if data is not None else "GET")
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    body = resp.read()
                    self.last = time.monotonic()
                    self.stats[f"http_{resp.status}"] += 1
                    return resp.status, dict(resp.headers.items()), body
            except urllib.error.HTTPError as exc:
                self.last = time.monotonic()
                body = exc.read()
                self.stats[f"http_{exc.code}"] += 1
                if exc.code in (400, 401, 403, 404):
                    return exc.code, dict(exc.headers.items()) if exc.headers else {}, body
                last_error = exc
                if exc.code == 429 or exc.code >= 500:
                    time.sleep(min(45, 2 ** min(attempt, 5) + random.random() * 3))
                    continue
                raise
            except Exception as exc:
                self.stats["network_error"] += 1
                last_error = exc
                if attempt + 1 < self.attempts:
                    time.sleep(min(30, 2 ** min(attempt, 4) + random.random() * 2))
                    continue
        raise RuntimeError(f"request failed: {url}: {last_error!r}")

    def get_json(self, url: str, params: dict[str, Any] | None = None) -> tuple[int, Any, str]:
        if params:
            query = urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})
            url += ("&" if "?" in url else "?") + query
        status, headers, body = self.request(url)
        text = body.decode("utf-8", "replace")
        try:
            payload = json.loads(text)
        except Exception:
            payload = {"_raw_text": text[:5000]}
        return status, payload, url

    def rpc(self, method: str, params: list[Any]) -> Any:
        data = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode()
        status, _, body = self.request(RPC_URL, data=data, headers={"Content-Type": "application/json"})
        if status != 200:
            raise RuntimeError(f"RPC {method} HTTP {status}: {body[:500]!r}")
        payload = json.loads(body)
        if payload.get("error"):
            raise RuntimeError(f"RPC {method}: {payload['error']}")
        return payload.get("result")


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = sorted({key for row in rows for key in row}) if rows else ["empty"]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: jdump(v) if isinstance(v, (dict, list, tuple)) else v for k, v in row.items()})


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def parse_transfer_logs(receipt: dict[str, Any] | None) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for log in (receipt or {}).get("logs") or []:
        topics = [str(x).lower() for x in (log.get("topics") or [])]
        if not topics or topics[0] != TRANSFER_TOPIC or len(topics) < 3:
            continue
        frm = "0x" + topics[1][-40:]
        to = "0x" + topics[2][-40:]
        if len(topics) >= 4:
            standard = "ERC721"
            token_id = intish(topics[3])
            amount = 1
        else:
            standard = "ERC20_OR_NONSTANDARD"
            token_id = None
            amount = intish(log.get("data"), 0) or 0
        rows.append({
            "contract": address(log.get("address")),
            "log_index": intish(log.get("logIndex")),
            "from_address": frm,
            "to_address": to,
            "standard": standard,
            "token_id": str(token_id) if token_id is not None else None,
            "amount_raw": str(amount),
        })
    return rows


def decode_seadrop_log(log: dict[str, Any]) -> dict[str, Any] | None:
    topics = [str(x).lower() for x in (log.get("topics") or [])]
    if not topics or topics[0] != SEADROP_TOPIC or len(topics) < 4:
        return None
    data = str(log.get("data") or "0x").removeprefix("0x")
    words = [data[i:i+64] for i in range(0, len(data), 64) if len(data[i:i+64]) == 64]
    if len(words) < 5:
        return None
    return {
        "nft_contract": "0x" + topics[1][-40:],
        "minter": "0x" + topics[2][-40:],
        "fee_recipient": "0x" + topics[3][-40:],
        "payer": "0x" + words[0][-40:],
        "quantity": int(words[1], 16),
        "unit_mint_price_wei": int(words[2], 16),
        "fee_bps": int(words[3], 16),
        "drop_stage_index": int(words[4], 16),
        "log_index": intish(log.get("logIndex")),
    }


def exact_tx_bundle(client: Client, tx_hash: str) -> dict[str, Any]:
    tx = client.rpc("eth_getTransactionByHash", [tx_hash])
    receipt = client.rpc("eth_getTransactionReceipt", [tx_hash])
    block = None
    if receipt and receipt.get("blockNumber"):
        block = client.rpc("eth_getBlockByNumber", [receipt["blockNumber"], False])
    internal: list[Any] = []
    rest: dict[str, Any] = {}
    for base in EXPLORERS:
        for suffix in ("", "/token-transfers", "/internal-transactions", "/logs", "/raw-trace"):
            key = base.split("//", 1)[1].split("/", 1)[0] + suffix.replace("/", "_")
            try:
                status, payload, url = client.get_json(f"{base}/api/v2/transactions/{tx_hash}{suffix}")
                rest[key] = {"status": status, "url": url, "payload": payload}
                if suffix == "/internal-transactions" and status == 200:
                    items = payload.get("items") if isinstance(payload, dict) else payload
                    if isinstance(items, list) and items:
                        internal = items
            except Exception as exc:
                rest[key] = {"status": 0, "error": repr(exc)}
    return {"tx": tx, "receipt": receipt, "block": block, "internal_transactions": internal, "rest": rest}


def account_action(client: Client, wallet: str, action: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    attempts: list[dict[str, Any]] = []
    for base in EXPLORERS:
        params = {
            "module": "account",
            "action": action,
            "address": wallet,
            "startblock": 0,
            "endblock": 99999999,
            "sort": "asc",
            "page": 1,
            "offset": 10000,
        }
        try:
            status, payload, url = client.get_json(f"{base}/api", params)
            result = payload.get("result") if isinstance(payload, dict) else None
            rows = result if isinstance(result, list) else []
            attempts.append({"source": base, "status": status, "url": url, "rows": len(rows), "message": payload.get("message") if isinstance(payload, dict) else None})
            if rows:
                return rows, {"selected_source": base, "attempts": attempts, "truncated_possible": len(rows) >= 10000}
        except Exception as exc:
            attempts.append({"source": base, "status": 0, "error": repr(exc), "rows": 0})
    return [], {"selected_source": None, "attempts": attempts, "truncated_possible": False}


def paginate_v2(client: Client, url: str, max_pages: int = 400) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    params: dict[str, Any] = {}
    seen: set[str] = set()
    for page in range(1, max_pages + 1):
        status, payload, resolved = client.get_json(url, params or None)
        if status != 200 or not isinstance(payload, dict):
            return rows, {"status": status, "pages": page - 1, "url": resolved, "complete": False, "error": payload}
        items = payload.get("items") or []
        if not isinstance(items, list):
            return rows, {"status": status, "pages": page - 1, "url": resolved, "complete": False, "error": "items_not_list"}
        rows.extend(x for x in items if isinstance(x, dict))
        nxt = payload.get("next_page_params")
        if not nxt:
            return rows, {"status": status, "pages": page, "url": resolved, "complete": True}
        key = jdump(nxt)
        if key in seen:
            return rows, {"status": status, "pages": page, "url": resolved, "complete": False, "error": "repeated_cursor"}
        seen.add(key)
        params = dict(nxt)
    return rows, {"status": 200, "pages": max_pages, "url": url, "complete": False, "error": "page_limit"}


def address_history(client: Client, wallet: str) -> dict[str, Any]:
    tx_rows, tx_meta = account_action(client, wallet, "txlist")
    nft_rows, nft_meta = account_action(client, wallet, "tokennfttx")
    erc1155_rows, erc1155_meta = account_action(client, wallet, "token1155tx")
    v2_tx: list[dict[str, Any]] = []
    v2_transfers: list[dict[str, Any]] = []
    v2_meta: dict[str, Any] = {}
    if not tx_rows or not nft_rows:
        for base in EXPLORERS:
            if not tx_rows:
                rows, meta = paginate_v2(client, f"{base}/api/v2/addresses/{wallet}/transactions")
                v2_meta[f"{base}_transactions"] = meta
                if rows:
                    v2_tx = rows
                    tx_rows = rows
            if not nft_rows:
                rows, meta = paginate_v2(client, f"{base}/api/v2/addresses/{wallet}/token-transfers")
                v2_meta[f"{base}_token_transfers"] = meta
                nft_like = []
                for row in rows:
                    token = row.get("token") or {}
                    standard = str(token.get("type") or token.get("standard") or row.get("type") or "").upper()
                    token_id = row.get("token_id") or row.get("tokenId") or ((row.get("total") or {}).get("token_id") if isinstance(row.get("total"), dict) else None)
                    if token_id is not None or "721" in standard or "1155" in standard:
                        nft_like.append(row)
                if nft_like:
                    v2_transfers = nft_like
                    nft_rows = nft_like
            if tx_rows and nft_rows:
                break
    return {
        "transactions": tx_rows,
        "nft_transfers": nft_rows,
        "erc1155_transfers": erc1155_rows,
        "meta": {"tx": tx_meta, "nft": nft_meta, "erc1155": erc1155_meta, "v2": v2_meta},
    }


def token_lifecycle(client: Client, contract: str, token_id: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    topic3 = topic_uint(token_id)
    attempts: list[dict[str, Any]] = []
    # A token-id filter is expected to be small even across the full chain.
    try:
        logs = client.rpc("eth_getLogs", [{"fromBlock": "0x0", "toBlock": "latest", "address": contract, "topics": [TRANSFER_TOPIC, None, None, topic3]}])
        if isinstance(logs, list):
            return logs, {"source": "OFFICIAL_RPC", "complete": True, "attempts": [{"source": RPC_URL, "rows": len(logs)}]}
    except Exception as exc:
        attempts.append({"source": RPC_URL, "error": repr(exc)})
    for base in EXPLORERS:
        try:
            status, payload, url = client.get_json(f"{base}/api", {
                "module": "logs", "action": "getLogs", "fromBlock": 0, "toBlock": "latest",
                "address": contract, "topic0": TRANSFER_TOPIC, "topic3": topic3,
                "topic0_3_opr": "and",
            })
            rows = payload.get("result") if isinstance(payload, dict) else None
            rows = rows if isinstance(rows, list) else []
            attempts.append({"source": base, "status": status, "url": url, "rows": len(rows)})
            if rows:
                return rows, {"source": base, "complete": len(rows) < 1000, "attempts": attempts}
        except Exception as exc:
            attempts.append({"source": base, "error": repr(exc)})
    return [], {"source": None, "complete": False, "attempts": attempts}


def verify_known_mint(client: Client, wallet_row: dict[str, Any], mint: dict[str, Any], raw_dir: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    tx_hash = mint["tx_hash"]
    bundle = exact_tx_bundle(client, tx_hash)
    write_json(raw_dir / f"tx_{tx_hash}.json", bundle)
    receipt = bundle.get("receipt") or {}
    transfers = parse_transfer_logs(receipt)
    seadrop = [x for x in (decode_seadrop_log(log) for log in receipt.get("logs") or []) if x]
    matching_sd = [x for x in seadrop if x["nft_contract"] == mint["contract"] and x["minter"] == mint["minter"] and x["log_index"] == mint["log_index"]]
    matching_mints = [x for x in transfers if x["contract"] == mint["contract"] and x["from_address"] == ZERO and x["to_address"] == mint["minter"]]
    lifecycle_rows: list[dict[str, Any]] = []
    for t in matching_mints:
        if t.get("token_id") is None:
            continue
        logs, meta = token_lifecycle(client, mint["contract"], t["token_id"])
        lifecycle_rows.append({
            "wallet": wallet_row["wallet"], "source_tx_hash": tx_hash, "contract": mint["contract"],
            "token_id": t["token_id"], "lifecycle_log_count": len(logs), "lifecycle_complete": meta.get("complete"),
            "lifecycle_source": meta.get("source"), "lifecycle_meta": meta, "lifecycle_logs": logs,
        })
    sd = matching_sd[0] if matching_sd else None
    tx = bundle.get("tx") or {}
    block = bundle.get("block") or {}
    result = {
        "wallet": wallet_row["wallet"], "priority": wallet_row["priority"], "tx_hash": tx_hash,
        "contract": mint["contract"], "collection_name": mint["collection_name"],
        "receipt_found": bool(receipt), "receipt_status": intish(receipt.get("status")),
        "block_number": intish(receipt.get("blockNumber")), "block_hash": receipt.get("blockHash"),
        "block_timestamp": intish(block.get("timestamp")), "tx_from": address(tx.get("from")), "tx_to": address(tx.get("to")),
        "expected_minter": mint["minter"], "expected_payer": mint["payer"], "expected_quantity": mint["quantity"],
        "expected_price_wei": mint["unit_mint_price_wei"], "expected_stage": mint["drop_stage_index"],
        "decoded_seadrop": sd, "seadrop_match": bool(sd), "zero_transfer_count": len(matching_mints),
        "zero_transfer_quantity": sum(int(x["amount_raw"]) for x in matching_mints),
        "minted_token_ids": [x["token_id"] for x in matching_mints],
        "payer_equals_minter": mint["payer"] == mint["minter"],
        "canonical_match": bool(sd)
            and intish(receipt.get("status")) == 1
            and int(sd["quantity"]) == int(mint["quantity"])
            and int(sd["unit_mint_price_wei"]) == int(mint["unit_mint_price_wei"])
            and int(sd["drop_stage_index"]) == int(mint["drop_stage_index"])
            and len(matching_mints) == int(mint["quantity"]),
    }
    return result, lifecycle_rows


def verify_known_sale(client: Client, wallet_row: dict[str, Any], sale: dict[str, Any], raw_dir: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    tx_hash = sale["tx_hash"]
    bundle = exact_tx_bundle(client, tx_hash)
    write_json(raw_dir / f"tx_{tx_hash}.json", bundle)
    receipt = bundle.get("receipt") or {}
    tx = bundle.get("tx") or {}
    transfers = parse_transfer_logs(receipt)
    matching_nft = [x for x in transfers if x["contract"] == sale["contract"] and x.get("token_id") == str(sale["token_id"])]
    seller_to_buyer = [x for x in matching_nft if x["from_address"] == sale["seller"] and x["to_address"] == sale["buyer"]]
    erc20_to_seller = [x for x in transfers if x["standard"] == "ERC20_OR_NONSTANDARD" and x["to_address"] == sale["seller"] and int(x["amount_raw"]) > 0]
    native_to_seller = []
    for item in bundle.get("internal_transactions") or []:
        to_addr = address(item.get("to"))
        value = intish(item.get("value") if not isinstance(item.get("value"), dict) else item["value"].get("value"), 0) or 0
        if to_addr == sale["seller"] and value > 0:
            native_to_seller.append({"from": address(item.get("from")), "to": to_addr, "value_wei": value})
    order_logs = []
    for log in receipt.get("logs") or []:
        topics = [str(x).lower() for x in (log.get("topics") or [])]
        if topics and topics[0] == ORDER_FULFILLED_TOPIC:
            order_logs.append({"address": address(log.get("address")), "log_index": intish(log.get("logIndex")), "topics": topics, "data": log.get("data")})
    lifecycle_logs, lifecycle_meta = token_lifecycle(client, sale["contract"], sale["token_id"])
    lifecycle_transfer_rows = []
    for log in lifecycle_logs:
        topics = [str(x).lower() for x in (log.get("topics") or [])]
        if len(topics) >= 4:
            lifecycle_transfer_rows.append({
                "block_number": intish(log.get("blockNumber") or log.get("block_number")),
                "tx_hash": str(log.get("transactionHash") or log.get("transaction_hash") or "").lower(),
                "log_index": intish(log.get("logIndex") or log.get("log_index")),
                "from_address": "0x" + topics[1][-40:], "to_address": "0x" + topics[2][-40:],
            })
    prior_receipts = [x for x in lifecycle_transfer_rows if x["to_address"] == sale["seller"] and x["tx_hash"] != tx_hash]
    prior_receipts.sort(key=lambda x: ((x.get("block_number") or 0), (x.get("log_index") or 0)))
    acquisition = prior_receipts[-1] if prior_receipts else None
    result = {
        "wallet": wallet_row["wallet"], "priority": wallet_row["priority"], "tx_hash": tx_hash,
        "contract": sale["contract"], "collection_name": sale["collection_name"], "token_id": sale["token_id"],
        "expected_seller": sale["seller"], "expected_buyer": sale["buyer"], "source_price_native": sale["price_native"],
        "receipt_found": bool(receipt), "receipt_status": intish(receipt.get("status")),
        "block_number": intish(receipt.get("blockNumber")), "block_hash": receipt.get("blockHash"),
        "tx_from": address(tx.get("from")), "tx_to": address(tx.get("to")), "top_level_value_wei": intish(tx.get("value"), 0),
        "matching_nft_transfer_count": len(matching_nft), "seller_to_buyer_match": bool(seller_to_buyer),
        "erc20_payments_to_seller": erc20_to_seller, "native_payments_to_seller": native_to_seller,
        "order_fulfilled_log_count": len(order_logs), "order_fulfilled_logs": order_logs,
        "sale_receipt_verified": intish(receipt.get("status")) == 1 and bool(seller_to_buyer) and bool(order_logs),
        "seller_payment_proven": bool(erc20_to_seller or native_to_seller),
        "token_lifecycle_complete": lifecycle_meta.get("complete"), "token_lifecycle_source": lifecycle_meta.get("source"),
        "prior_acquisition_transfer": acquisition,
        "acquisition_cost_status": "UNRESOLVED_TRANSFER_ONLY" if acquisition else "NO_PRIOR_ACQUISITION_FOUND",
    }
    lifecycle = {
        "wallet": wallet_row["wallet"], "contract": sale["contract"], "token_id": sale["token_id"],
        "sale_tx_hash": tx_hash, "lifecycle_meta": lifecycle_meta, "lifecycle_transfers": lifecycle_transfer_rows,
    }
    return result, lifecycle


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wallets", default="wallet-verification/wallets.json")
    parser.add_argument("--out", default="out-wallet-verification")
    args = parser.parse_args()
    wallets = json.loads(Path(args.wallets).read_text(encoding="utf-8"))
    out = Path(args.out)
    raw_dir = out / "raw"
    out.mkdir(parents=True, exist_ok=True)
    raw_dir.mkdir(parents=True, exist_ok=True)
    client = Client()

    wallet_summaries: list[dict[str, Any]] = []
    tx_history_rows: list[dict[str, Any]] = []
    nft_history_rows: list[dict[str, Any]] = []
    mint_results: list[dict[str, Any]] = []
    sale_results: list[dict[str, Any]] = []
    lifecycle_rows: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []

    head = intish(client.rpc("eth_blockNumber", []), 0) or 0
    chain_id = intish(client.rpc("eth_chainId", []), 0) or 0

    for index, row in enumerate(wallets, 1):
        wallet = row["wallet"]
        print(f"[{index}/{len(wallets)}] {wallet}", flush=True)
        try:
            code = client.rpc("eth_getCode", [wallet, "latest"])
            balance = intish(client.rpc("eth_getBalance", [wallet, "latest"]), 0) or 0
            nonce = intish(client.rpc("eth_getTransactionCount", [wallet, "latest"]), 0) or 0
            history = address_history(client, wallet)
            write_json(raw_dir / f"address_{wallet}.json", history)
            for item in history["transactions"]:
                tx_history_rows.append({"audit_wallet": wallet, **item})
            for item in history["nft_transfers"]:
                nft_history_rows.append({"audit_wallet": wallet, **item})
            known_tx_hashes = {x["tx_hash"] for x in row.get("known_mints", [])} | {x["tx_hash"] for x in row.get("known_sales", [])}
            history_tx_hashes = {
                str(x.get("hash") or x.get("transaction_hash") or x.get("tx_hash") or "").lower()
                for x in history["transactions"] + history["nft_transfers"]
            }
            wallet_summaries.append({
                "wallet": wallet, "priority": row["priority"], "priority_points": row["priority_points"],
                "is_contract": code not in (None, "0x", "0x0", "0x00"), "code_length_hex": len(code or ""),
                "balance_wei": balance, "nonce": nonce, "known_mint_count": len(row.get("known_mints", [])),
                "known_sale_count": len(row.get("known_sales", [])), "transaction_history_rows": len(history["transactions"]),
                "nft_history_rows": len(history["nft_transfers"]), "erc1155_history_rows": len(history["erc1155_transfers"]),
                "known_transactions_found_in_index": len(known_tx_hashes & history_tx_hashes),
                "known_transactions_expected": len(known_tx_hashes), "history_meta": history["meta"],
                "strength_status": "NOT_EVALUATED", "production_approved": False,
            })
            for mint in row.get("known_mints", []):
                try:
                    verified, lifecycles = verify_known_mint(client, row, mint, raw_dir)
                    mint_results.append(verified)
                    lifecycle_rows.extend(lifecycles)
                except Exception as exc:
                    errors.append({"wallet": wallet, "stage": "known_mint", "tx_hash": mint["tx_hash"], "error": repr(exc)})
            for sale in row.get("known_sales", []):
                try:
                    verified, lifecycle = verify_known_sale(client, row, sale, raw_dir)
                    sale_results.append(verified)
                    lifecycle_rows.append(lifecycle)
                except Exception as exc:
                    errors.append({"wallet": wallet, "stage": "known_sale", "tx_hash": sale["tx_hash"], "error": repr(exc)})
        except Exception as exc:
            errors.append({"wallet": wallet, "stage": "wallet", "error": repr(exc)})
            wallet_summaries.append({"wallet": wallet, "priority": row["priority"], "priority_points": row["priority_points"], "audit_status": "FAIL", "error": repr(exc), "strength_status": "NOT_EVALUATED", "production_approved": False})

    write_csv(out / "wallet_summary.csv", wallet_summaries)
    write_csv(out / "address_transactions.csv", tx_history_rows)
    write_csv(out / "address_nft_transfers.csv", nft_history_rows)
    write_csv(out / "known_mint_verification.csv", mint_results)
    write_csv(out / "known_sale_verification.csv", sale_results)
    write_json(out / "token_lifecycle_evidence.json", lifecycle_rows)
    write_csv(out / "errors.csv", errors)

    p0 = [x for x in wallets if x["priority"] == "P0"]
    p0_wallets = {x["wallet"] for x in p0}
    p0_mints = [x for x in mint_results if x["wallet"] in p0_wallets]
    p0_sales = [x for x in sale_results if x["wallet"] in p0_wallets]
    known_mint_expected = sum(len(x.get("known_mints", [])) for x in wallets)
    known_sale_expected = sum(len(x.get("known_sales", [])) for x in wallets)
    validation_failures: list[dict[str, Any]] = []
    if chain_id != CHAIN_ID:
        validation_failures.append({"code": "WRONG_CHAIN", "value": chain_id})
    if len(mint_results) != known_mint_expected:
        validation_failures.append({"code": "KNOWN_MINT_RESULT_COUNT_MISMATCH", "expected": known_mint_expected, "actual": len(mint_results)})
    if len(sale_results) != known_sale_expected:
        validation_failures.append({"code": "KNOWN_SALE_RESULT_COUNT_MISMATCH", "expected": known_sale_expected, "actual": len(sale_results)})
    for row in p0_mints:
        if not row.get("canonical_match"):
            validation_failures.append({"code": "P0_MINT_NOT_CANONICALLY_VERIFIED", "wallet": row["wallet"], "tx_hash": row["tx_hash"]})
    for row in p0_sales:
        if not row.get("sale_receipt_verified"):
            validation_failures.append({"code": "P0_SALE_NOT_RECEIPT_VERIFIED", "wallet": row["wallet"], "tx_hash": row["tx_hash"]})
    if not p0_mints:
        validation_failures.append({"code": "P0_MINT_RESULT_MISSING"})
    if not p0_sales:
        validation_failures.append({"code": "P0_SALE_RESULT_MISSING"})

    validation = {
        "status": "PASS" if not validation_failures else "FAIL",
        "chain_id": chain_id,
        "source_head_block": head,
        "wallet_count": len(wallets),
        "p0_wallet_count": len(p0),
        "known_mint_expected": known_mint_expected,
        "known_mint_verified_rows": len(mint_results),
        "known_mint_canonical_matches": sum(bool(x.get("canonical_match")) for x in mint_results),
        "known_sale_expected": known_sale_expected,
        "known_sale_verified_rows": len(sale_results),
        "known_sale_receipt_matches": sum(bool(x.get("sale_receipt_verified")) for x in sale_results),
        "address_transaction_rows": len(tx_history_rows),
        "address_nft_transfer_rows": len(nft_history_rows),
        "error_count": len(errors),
        "failures": validation_failures,
        "production_approved_wallets": 0,
        "decision_use": "P0_P1_CANONICAL_VERIFICATION_ONLY",
    }
    write_json(out / "VALIDATION.json", validation)
    write_json(out / "REQUEST_STATS.json", client.stats)

    manifest = []
    for path in sorted(out.rglob("*")):
        if path.is_file():
            manifest.append({"path": str(path.relative_to(out)), "bytes": path.stat().st_size, "sha256": sha256_file(path)})
    write_json(out / "MANIFEST.json", manifest)
    print(json.dumps(validation, sort_keys=True), flush=True)
    if validation["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
